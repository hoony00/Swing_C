package swing.components;

public class Main {

	public static void main(String[] args) {
		MainFrame mf = new MainFrame("내 프레임", 600, 500);

	}

}
